﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Counter : MonoBehaviour {

	public Text count;
	public AudioClip beep;
	private bool loading;
	public int i;
	void Start(){
		count.text = " ";
		loading = true;
	}

	void Update(){
		if (loading) {
			InvokeRepeating("CountUp2", 0f, .05f);
		}

		if (Input.GetKeyDown (KeyCode.Escape)) {
			SceneManager.LoadScene (0);
			loading = false;

		}

		if (Input.GetKeyDown (KeyCode.Delete)) {
			StartCoroutine(switchScene());
			loading = false;
		}


	}
	void CountUp2(){
		if (i <= 38956) {
			count.text = i + " " + "KB";
			i = (i + 1);
		}
		if (i == 38956) {
			StartCoroutine(switchScene());
		}
	}

	public IEnumerator switchScene () {
		GlobalVariables.beep = true;
		yield return new WaitForSeconds(2);
		SceneManager.LoadScene (0);
	}
}