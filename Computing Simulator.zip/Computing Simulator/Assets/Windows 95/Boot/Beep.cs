﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Beep : MonoBehaviour {

	public AudioClip beep;
	public bool playBeep = false;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		if (GlobalVariables.beep == true) {
			AudioSource audio = GetComponent<AudioSource> ();
			audio.clip = beep;
			audio.Play ();
			GlobalVariables.beep = false;
		}
	}
}
