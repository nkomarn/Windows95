﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class BIOSSelcetion : MonoBehaviour {
	public Sprite systemInformation;
	public Sprite systemInformation2;
	public Button SI;
	public Sprite systemSettings;
	public Sprite systemSettings2;
	public Button SyS;
	public Sprite dateAndTime;
	public Sprite dateAndTime2;
	public Button DAT;
	public Sprite startOptions;
	public Sprite startOptions2;
	public Button SO;
	public Sprite bootManager;
	public Sprite bootManager2;
	public Button BM;
	public Sprite systemEventLogs;
	public Sprite systemEventLogs2;
	public Button SEL;
	public Sprite userSecurity;
	public Sprite userSecurity2;
	public Button US;
	public Sprite saveSettings;
	public Sprite saveSettings2;
	public Button SaS;
	public Sprite restoreSettings;
	public Sprite restoreSettings2;
	public Button RS;
	public Sprite loadDefaultSettings;
	public Sprite loadDefaultSettings2;
	public Button LDS;
	public Sprite exitSetup;
	public Sprite exitSetup2;
	public Button ES;
	private int selection = 1;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.UpArrow)) {
			selection = (selection - 1);
            SelectChange();
		}
		if (Input.GetKeyDown (KeyCode.DownArrow)) {
			selection = (selection + 1);
            SelectChange();
        }
		if (selection > 11) {
			selection = 1;
            SelectChange();
        }
		if (selection < 1) {
			selection = 11;
            SelectChange();
        }
	}


	void SelectChange(){
		switch (selection) {
		default:
			SI.image.sprite = systemInformation2;

                RS.image.sprite = restoreSettings;
                SyS.image.sprite = systemSettings;
                DAT.image.sprite = dateAndTime;
                SO.image.sprite = startOptions;
                BM.image.sprite = bootManager;
                SEL.image.sprite = systemEventLogs;
                US.image.sprite = userSecurity;
                SaS.image.sprite = saveSettings;
                LDS.image.sprite = loadDefaultSettings;
                ES.image.sprite = exitSetup;
            break;
		case 1:
			SI.image.sprite = systemInformation2;

                RS.image.sprite = restoreSettings;
                SyS.image.sprite = systemSettings;
                DAT.image.sprite = dateAndTime;
                SO.image.sprite = startOptions;
                BM.image.sprite = bootManager;
                SEL.image.sprite = systemEventLogs;
                US.image.sprite = userSecurity;
                SaS.image.sprite = saveSettings;
                LDS.image.sprite = loadDefaultSettings;
                ES.image.sprite = exitSetup;
            break;
		case 2:
			SI.image.sprite = systemInformation;
                ES.image.sprite = exitSetup;

                RS.image.sprite = restoreSettings;
                DAT.image.sprite = dateAndTime;
                SO.image.sprite = startOptions;
                BM.image.sprite = bootManager;
                SEL.image.sprite = systemEventLogs;
                US.image.sprite = userSecurity;
                SaS.image.sprite = saveSettings;
                LDS.image.sprite = loadDefaultSettings;
                SyS.image.sprite = systemSettings2;
            break;
		case 3:
			SyS.image.sprite = systemSettings;
                ES.image.sprite = exitSetup;
                SI.image.sprite = systemInformation;

                RS.image.sprite = restoreSettings;
                SO.image.sprite = startOptions;
                BM.image.sprite = bootManager;
                SEL.image.sprite = systemEventLogs;
                US.image.sprite = userSecurity;
                SaS.image.sprite = saveSettings;
                LDS.image.sprite = loadDefaultSettings;
                DAT.image.sprite = dateAndTime2;
            break;
		case 4:
			DAT.image.sprite = dateAndTime;
                ES.image.sprite = exitSetup;
                SI.image.sprite = systemInformation;
                SyS.image.sprite = systemSettings;

                RS.image.sprite = restoreSettings;
                BM.image.sprite = bootManager;
                SEL.image.sprite = systemEventLogs;
                US.image.sprite = userSecurity;
                SaS.image.sprite = saveSettings;
                LDS.image.sprite = loadDefaultSettings;
                SO.image.sprite = startOptions2;
            break;
		case 5:
			SO.image.sprite = startOptions;
                ES.image.sprite = exitSetup;
                SI.image.sprite = systemInformation;
                SyS.image.sprite = systemSettings;
                DAT.image.sprite = dateAndTime;

                RS.image.sprite = restoreSettings;
                SEL.image.sprite = systemEventLogs;
                US.image.sprite = userSecurity;
                SaS.image.sprite = saveSettings;
                LDS.image.sprite = loadDefaultSettings;
                BM.image.sprite = bootManager2;
            break;
		case 6:
			BM.image.sprite = bootManager;
                ES.image.sprite = exitSetup;
                SI.image.sprite = systemInformation;
                SyS.image.sprite = systemSettings;
                DAT.image.sprite = dateAndTime;
                SO.image.sprite = startOptions;

                RS.image.sprite = restoreSettings;
                US.image.sprite = userSecurity;
                SaS.image.sprite = saveSettings;
                LDS.image.sprite = loadDefaultSettings;
                SEL.image.sprite = systemEventLogs2;
            break;
		case 7:
			SEL.image.sprite = systemEventLogs;
                ES.image.sprite = exitSetup;
                SI.image.sprite = systemInformation;
                SyS.image.sprite = systemSettings;
                DAT.image.sprite = dateAndTime;
                SO.image.sprite = startOptions;
                BM.image.sprite = bootManager;

                RS.image.sprite = restoreSettings;
                SaS.image.sprite = saveSettings;
                LDS.image.sprite = loadDefaultSettings;
                US.image.sprite = userSecurity2;
            break;
		case 8:
			US.image.sprite = userSecurity;
                ES.image.sprite = exitSetup;
                SI.image.sprite = systemInformation;
                SyS.image.sprite = systemSettings;
                DAT.image.sprite = dateAndTime;
                SO.image.sprite = startOptions;
                BM.image.sprite = bootManager;
                SEL.image.sprite = systemEventLogs;

                RS.image.sprite = restoreSettings;
                LDS.image.sprite = loadDefaultSettings;
                SaS.image.sprite = saveSettings2;
            break;
		case 9:
			SaS.image.sprite = saveSettings;
                ES.image.sprite = exitSetup;
                SI.image.sprite = systemInformation;
                SyS.image.sprite = systemSettings;
                DAT.image.sprite = dateAndTime;
                SO.image.sprite = startOptions;
                BM.image.sprite = bootManager;
                SEL.image.sprite = systemEventLogs;
                US.image.sprite = userSecurity;
                LDS.image.sprite = loadDefaultSettings;

                RS.image.sprite = restoreSettings2;
            break;
		case 10:
			RS.image.sprite = restoreSettings;
                ES.image.sprite = exitSetup;
                SI.image.sprite = systemInformation;
                SyS.image.sprite = systemSettings;
                DAT.image.sprite = dateAndTime;
                SO.image.sprite = startOptions;
                BM.image.sprite = bootManager;
                SEL.image.sprite = systemEventLogs;
                US.image.sprite = userSecurity;
                SaS.image.sprite = saveSettings;
                RS.image.sprite = restoreSettings;
                LDS.image.sprite = loadDefaultSettings2;
            break;
		case 11:
			LDS.image.sprite = loadDefaultSettings;
               
                SI.image.sprite = systemInformation;
                SyS.image.sprite = systemSettings;
                DAT.image.sprite = dateAndTime;
                SO.image.sprite = startOptions;
                BM.image.sprite = bootManager;
                SEL.image.sprite = systemEventLogs;
                US.image.sprite = userSecurity;
                SaS.image.sprite = saveSettings;
                RS.image.sprite = restoreSettings;
                ES.image.sprite = exitSetup2;
            break;

		}
	}
}