﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlobalVariables : MonoBehaviour {

	public static bool startmenuEnabled;
	public static bool shutdown;
	public static bool programsSubmenu;
	public static bool fixStart;

	void Start	() {
		startmenuEnabled = false;
		shutdown = false;
		fixStart = false;
		programsSubmenu = false;
	}
}
