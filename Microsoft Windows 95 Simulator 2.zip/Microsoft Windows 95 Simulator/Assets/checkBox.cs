﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class checkBox : MonoBehaviour {

	public Button CheckBoxButton;
	private Button check;
	public Canvas WelcomeWindow;
	private Canvas Welcome;
	public Sprite newsprite;
	public Sprite newsprite1;
	public int dab;
	// Use this for initialization
	void Start () {

		check = CheckBoxButton.GetComponent<Button> ();
		check.onClick.AddListener (TaskOnClick);
		Welcome = WelcomeWindow.GetComponent<Canvas> ();
		Welcome.enabled = true;
		check.image.sprite = newsprite1;
	}

	// Update is called once per frame
	void TaskOnClick () {
		switch (dab){
		default:
			check.image.sprite = newsprite1;
			break;
		case 1:
			check.image.sprite = newsprite;
			break;
		case 2:
			check.image.sprite = newsprite1;
			break;
		}
	}
}
