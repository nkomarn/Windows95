﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class closeButton : MonoBehaviour {

	public Button CloseButton;
	public Canvas WelcomeWindow;
	private Canvas Welcome;
	// Use this for initialization
	void Start () {
		
		Button close = CloseButton.GetComponent<Button> ();
		close.onClick.AddListener (TaskOnClick);
		Welcome = WelcomeWindow.GetComponent<Canvas> ();
		Welcome.enabled = true;
	}
	
	// Update is called once per frame
	void TaskOnClick () {
		Welcome.enabled = false;
	}
}
